# git init
# git add README.md
# git add .
# git commit -m "first commit"
# git branch -M main
# git remote add origin https://github.com/Laminito/RBB.git
# git push -u origin main
